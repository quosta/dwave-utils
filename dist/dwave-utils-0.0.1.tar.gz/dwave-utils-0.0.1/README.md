# dwave-utils

A python lib that provides useful functions for D-Wave users.

## Installation

Install directly from PyPI:

`python3 -m pip install dwave-utils`

## Contributions

Pull requests are welcome!

Main contributors:

* Costantino Carugno
* Riccardo Nembrini